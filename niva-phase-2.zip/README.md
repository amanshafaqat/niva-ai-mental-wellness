# NIVA — AI Mental Wellness Companion
> *"Someone to talk to."*  
> **Phase 2.1: Authentication Security Hardening & RBAC Core**

---

## 1. What NIVA Is

**NIVA** is a privacy-conscious AI mental wellness companion designed for diverse generations—including students, working adults, and senior citizens. NIVA offers a calm, empathetic, and confidential conversational space for emotional grounding, stress alleviation, and daily mindfulness check-ins.

### Critical Safety & Clinical Disclaimer
NIVA is **NOT** a licensed psychiatrist, clinical psychologist, medical doctor, or a replacement for professional clinical care. NIVA never provides medical diagnoses, pharmacological advice, or instructions facilitating self-harm or violence. If a user is experiencing an acute mental health crisis, NIVA directs them to professional human crisis intervention (such as the **988 Suicide & Crisis Lifeline** in the United States and Canada).

---

## 2. Current Status: Phase 2.1 Authentication Security Hardening

This repository reflects **Phase 2.1: Authentication Security Hardening**, completing rigorous security validation on top of the Phase 1 & 2 identity core.

### Phase 2.1 Security Hardening Accomplishments
1. **Cryptographic Google OAuth State Validation (CSRF & Replay Defense)**:
   - High-entropy 256-bit state values (`crypto.randomBytes(32).toString('hex')`) generated at OAuth initiation.
   - Associated with an `HttpOnly`, `SameSite=Lax`, short-lived (10-minute) `niva_oauth_state` cookie.
   - Callback endpoints (`GET /auth/google/callback` and `GET /api/auth/google/callback`) enforce strict state validation.
   - Verification uses `crypto.timingSafeEqual` to eliminate timing attack vectors.
   - State cookies are immediately invalidated and purged upon receipt to prevent replay attacks.
2. **Complete Removal of Fake / Demo User Fallbacks**:
   - Eliminated fabricated in-memory fallbacks (`user@niva.wellness`, `demo-user@niva.wellness`).
   - Removed in-memory user and session stores (`memoryUsers`, `memorySessions`, `handleFallbackSession`).
   - Database failures are caught, internally logged with stack traces for operations, and mapped to safe generic errors (`500 InternalServerErrorException`). Database internals and connection strings are strictly masked from clients.
3. **OAuth Token Minimization**:
   - Evaluated the Prisma `Account` model against operational requirements.
   - Applied the principle of data minimization: eliminated unused `accessToken`, `refreshToken`, and `idToken` database columns via Prisma migration `20260915110000_oauth_token_minimization`.
   - Federated identities are mapped solely by verified `providerAccountId` (`sub` claim) without storing raw third-party access credentials.
4. **Session & Cookie Security**:
   - Sessions are identified by high-entropy random identifiers (`niva_sess_*`).
   - Transmitted exclusively over `HttpOnly`, `SameSite=Lax` cookies (with `Secure` active in production).
   - `GET /auth/me` returns sanitized user profiles: zero secrets, password hashes, or token credentials.
   - `POST /auth/logout` invalidates the server session record and clears client cookies.
5. **RBAC Guard Enforcement & Anti-Escalation Boundaries**:
   - Roles: `USER` (default), `GUARDIAN`, `ADMIN`.
   - `PATCH /users/me/role` strictly rejects self-assigned role changes with `403 Forbidden` and records security audit events (`ROLE_CHANGE_REJECTED`).
   - `AdminGuard` and `GuardianGuard` block unauthorized requests deterministically.
6. **Platform Administrator Bootstrap**:
   - Governed strictly by the `INITIAL_ADMIN_EMAIL` environment variable.
   - Evaluated using trimmed, case-insensitive comparison (`email.toLowerCase().trim() === initialAdminEmail.toLowerCase().trim()`).
   - Standard logins default safely to `USER`. No hardcoded admin emails or backdoors exist.
7. **Security Audit Log Redaction**:
   - `AuditService` automatically redacts sensitive keywords (`password`, `token`, `secret`, `accesstoken`, `refreshtoken`, `idtoken`, `credential`, `key`, `gemini`, `message`, `prompt`, `conversation`) in audit metadata.
   - Immutable audit logs record `LOGIN_SUCCESS`, `LOGIN_FAILURE`, `LOGOUT`, `ACCOUNT_CREATED`, `ROLE_CHANGE_REJECTED`, and `RBAC_ACCESS_DENIED`.

---

## 3. Architecture

NIVA follows a decoupled, privacy-first, full-stack architecture:

```
                          ┌──────────────────────────┐
                          │   Next.js 14 Frontend    │
                          │ (Tailwind, Lucide, Calm) │
                          └─────────────┬────────────┘
                                        │  Bearer Session Token
                                        ▼
                          ┌──────────────────────────┐
                          │   NestJS REST Backend    │
                          │   - Helmet & CORS        │
                          │   - RolesGuard (RBAC)    │
                          │   - Global Exception     │
                          └──────┬────────────┬──────┘
                                 │            │
             ┌───────────────────┴──┐      ┌──┴───────────────────┐
             │                      │      │                      │
             ▼                      ▼      ▼                      ▼
    ┌─────────────────┐    ┌─────────────┐ ┌───────────────┐ ┌───────────────┐
    │  Google OAuth   │    │ Prisma ORM  │ │ Audit Logger  │ │  AIProvider   │
    │ Identity Server │    │ (PostgreSQL)│ │  (Security)   │ │  Abstraction │
    └─────────────────┘    └─────────────┘ └───────────────┘ └───────────────┘
```

1. **Client Identity**: The frontend authenticates exclusively using Google OAuth 2.0. No plaintext passwords or email verification pins are ever used.
2. **Session Verification**: The backend issues high-entropy cryptographically generated session tokens (`niva_sess_*`).
3. **RBAC Guard**: NestJS `@Roles(...)` metadata is evaluated on every protected request by `RolesGuard`.
4. **Audit Trail**: Sensitive actions (logins, logouts, RBAC rejections) generate immutable `AuditLog` records.
5. **AI Abstraction**: Core services interface with an abstract `AIProvider`, isolating NIVA from third-party vendor lock-in.

---

## 4. Tech Stack

- **Frontend**: Next.js (React 18/19), TypeScript, Tailwind CSS, Lucide Icons, Motion.
- **Backend**: NestJS, Express, TypeScript, class-validator, class-transformer.
- **Database**: PostgreSQL 14+, Prisma ORM.
- **Authentication**: Google OAuth 2.0 (Google Identity Services) + cryptographically secure session tokens.
- **Security & Infrastructure**: Helmet, NestJS Throttler/Rate-limiting, CORS, strictly native Node.js (no Docker or Docker Compose required).

---

## 5. Folder Structure

```
niva-project/
├── backend/                       # NestJS REST API Backend
│   ├── src/
│   │   ├── ai/                    # Vendor-agnostic AI Provider Abstraction
│   │   │   ├── abstracts/         # BaseAIProvider abstract class
│   │   │   ├── interfaces/        # AIProvider, AIMessage, SafetyEvaluation
│   │   │   ├── providers/         # Stub provider (Phase 1 placeholder)
│   │   │   ├── ai-provider.factory.ts
│   │   │   └── ai.module.ts
│   │   ├── audit/                 # Security Audit Logging Module
│   │   │   ├── audit.controller.ts# Protected GET /audit/logs (ADMIN only)
│   │   │   ├── audit.service.ts   # Immutable audit trail logger
│   │   │   └── audit.module.ts
│   │   ├── auth/                  # Google OAuth & Session Management
│   │   │   ├── dto/               # GoogleVerifyTokenDto, SessionDto
│   │   │   ├── guards/            # SessionAuthGuard
│   │   │   ├── auth.controller.ts # OAuth verify, session info, logout
│   │   │   ├── auth.service.ts    # User creation, session generation
│   │   │   └── auth.module.ts
│   │   ├── authorization/         # Role-Based Access Control (RBAC)
│   │   │   ├── roles.decorator.ts # @Roles() metadata decorator
│   │   │   ├── roles.guard.ts     # NestJS CanActivate RBAC guard
│   │   │   └── authorization.module.ts
│   │   ├── common/                # Shared Filters, Interceptors, DTOs
│   │   │   ├── filters/           # HttpExceptionFilter (sanitized errors)
│   │   │   └── dto/               # ApiResponseDto
│   │   ├── health/                # System Health Monitoring
│   │   │   ├── health.controller.ts# GET /health
│   │   │   └── health.service.ts
│   │   ├── prisma/                # PrismaClient Lifecycle Integration
│   │   │   ├── prisma.service.ts
│   │   │   └── prisma.module.ts
│   │   ├── users/                 # User Profile & Directory Management
│   │   │   ├── users.controller.ts# /users/me, guardian & admin test routes
│   │   │   └── users.service.ts
│   │   ├── app.module.ts          # Root NestJS Module
│   │   └── main.ts                # NestJS Application Bootstrap
│   ├── package.json
│   ├── tsconfig.json
│   └── nest-cli.json
├── frontend/                      # Next.js Modern Responsive UI
│   ├── src/
│   │   ├── app/                   # Next.js Layout & Page Routing
│   │   ├── components/            # Accessible, Calm Wellness Components
│   │   │   ├── ArchitectureViewer.tsx
│   │   │   ├── AuditLogViewer.tsx
│   │   │   ├── DashboardView.tsx
│   │   │   ├── DisclaimerBanner.tsx
│   │   │   ├── DownloadZipModal.tsx
│   │   │   ├── GoogleSignInModal.tsx
│   │   │   ├── HeroSection.tsx
│   │   │   ├── Navbar.tsx
│   │   │   ├── RoleTester.tsx
│   │   │   └── SystemHealthWidget.tsx
│   │   ├── lib/
│   │   │   ├── api.ts             # REST client wrapper
│   │   │   └── auth-context.tsx   # React AuthContext & session state
│   │   └── types.ts
│   ├── package.json
│   ├── tsconfig.json
│   └── next.config.js
├── prisma/                        # Database Architecture & Migrations
│   ├── schema.prisma              # User, Account, Session, AuditLog models
│   ├── seed.ts                    # Server admin seed script
│   └── migrations/                # Versioned SQL migration files
├── shared/                        # Shared Cross-Platform Types & Constants
│   ├── constants/roles.ts         # Role enum & permission definitions
│   ├── types/ai.ts                # AIProvider interface contract
│   ├── types/audit.ts             # AuditAction enum & entry definitions
│   ├── types/auth.ts              # AuthSession & Google payload definitions
│   └── types/user.ts              # User entity & profile interfaces
├── scripts/
│   └── package-project.ts         # Generates complete niva-phase-1.zip
├── .env.example                   # Root environment template
├── package.json                   # Root orchestrator & dev server scripts
├── README.md                      # Comprehensive Architecture Documentation
└── server.ts                      # Full-stack dev runner & API proxy
```

---

## 6. Prerequisites

To run NIVA natively on your local development machine:
- **Node.js**: v18.18.0 or v20.x+
- **npm**: v9+ (or `pnpm` / `yarn`)
- **PostgreSQL**: v14, v15, or v16 running locally or via a cloud provider.

---

## 7. Environment Variables

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Key variables:

| Variable | Description | Example |
| :--- | :--- | :--- |
| `DATABASE_URL` | PostgreSQL connection string | `postgresql://postgres:postgres@localhost:5432/niva_wellness?schema=public` |
| `GOOGLE_CLIENT_ID` | Google OAuth Client ID | `your-id.apps.googleusercontent.com` |
| `GOOGLE_CLIENT_SECRET`| Google OAuth Client Secret | `GOCSPX-your-secret` |
| `GOOGLE_CALLBACK_URL` | OAuth redirect callback URL | `http://localhost:3000/api/auth/google/callback` |
| `JWT_SECRET` | 32+ char secret for tokens | `a-very-secure-random-32-char-string` |
| `SESSION_SECRET` | 32+ char secret for sessions | `another-secure-random-32-char-string` |
| `PORT` | Web server listening port | `3000` |
| `INITIAL_ADMIN_EMAIL`| Server-side elevated admin | `admin@niva.internal` |

---

## 8. PostgreSQL Setup

1. Start your local PostgreSQL service:
   ```bash
   # macOS (Homebrew)
   brew services start postgresql@15

   # Linux (Ubuntu/Debian)
   sudo systemctl start postgresql
   ```
2. Create the `niva_wellness` database:
   ```sql
   CREATE DATABASE niva_wellness;
   ```
3. Update `DATABASE_URL` in `.env` to match your local credentials.

---

## 9. Google OAuth Setup

1. Open the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a project named **NIVA Mental Wellness**.
3. Configure the **OAuth Consent Screen**:
   - User Type: External.
   - App Name: NIVA.
   - Scopes: `openid`, `email`, `profile`.
4. Create **Credentials** -> **OAuth 2.0 Client IDs**:
   - Application Type: Web Application.
   - Authorized JavaScript Origins: `http://localhost:3000`.
   - Authorized Redirect URIs: `http://localhost:3000/api/auth/google/callback`.
5. Copy the Client ID and Secret into your `.env` file.

*Note: In development, NIVA includes an interactive verification suite with test personas so you can evaluate the session and RBAC logic even before configuring Google Cloud credentials.*

---

## 10. How to Run Frontend

To run the Next.js frontend standalone:
```bash
cd frontend
npm install
npm run dev
```
The frontend will start at `http://localhost:3000`.

---

## 11. How to Run Backend

To run the NestJS backend standalone:
```bash
cd backend
npm install
npm run start:dev
```
The NestJS server will start on port `3001` (or specified `PORT`), exposing `GET /health` and `/api/*`.

---

## 12. How to Run Database Migrations

1. Generate Prisma Client:
   ```bash
   npx prisma generate
   ```
2. Run migrations against your PostgreSQL instance:
   ```bash
   npx prisma migrate dev --name init
   ```
3. Seed the initial platform administrator:
   ```bash
   npx tsx prisma/seed.ts
   ```

---

## 13. How to Run Tests & Verification

NIVA includes automated security verification scripts and unit test suites:

```bash
# 1. Run Phase 2.1 Security Hardening Automated Verification (Root)
npx tsx scripts/verify-phase-2-1.ts

# 2. Run NestJS Backend Unit & RBAC Tests
cd backend
npm test

# Run specific test suites:
npm test -- auth.service.spec.ts   # Google OAuth, state verification, session handling
npm test -- rbac-guards.spec.ts    # UserGuard, GuardianGuard, AdminGuard
npm test -- health.controller.spec.ts
```

---

## 14. Security & Cybersecurity Notes

As a cybersecurity portfolio project, NIVA implements defense-in-depth principles from day one:
1. **Zero Plaintext Passwords**: Authentication is strictly federated via Google Identity Services. Password cracking and credential stuffing attack vectors are eliminated.
2. **Strict CSRF & Replay Defense**: OAuth flows generate 256-bit cryptographic state tokens validated via `crypto.timingSafeEqual` and destroyed immediately after single use.
3. **No Fake User Fallbacks**: Database errors are safely logged and return server error responses. The backend never fabricates mock or demo sessions on failure.
4. **Token Minimization**: Third-party OAuth tokens (`accessToken`, `refreshToken`, `idToken`) are discarded immediately after user claims verification; they are never stored in the database.
5. **Server-Enforced RBAC & Anti-Escalation**: Client-side role badges are decorative only. `RolesGuard` independently verifies permissions. The backend explicitly rejects and logs attempts to modify user roles via `PATCH /users/me/role`.
6. **No Unrestricted Admin Browsing**: Administrators **CANNOT** view user conversations. Future access models require cryptographic, time-bounded, audit-logged consent.
7. **Sanitized Exception Handling**: Database constraints, query internals, and stack traces are never leaked to external callers.
8. **Automated Audit Log Redaction**: Authentication and authorization events are audited with automatic redaction of secrets, tokens, API keys, and conversational message contents.

---

## 15. Production Readiness Status

| Subsystem | Readiness | Notes |
| :--- | :--- | :--- |
| **Authentication Core** | Production-Hardened | Real Google OAuth 2.0 flow, 256-bit CSRF state, single-use state cookie, timing-safe checks |
| **Session Security** | Production-Hardened | High-entropy server sessions, `HttpOnly`, `SameSite=Lax`, strict database backing |
| **RBAC Boundaries** | Production-Hardened | Strict role checks (`USER`, `GUARDIAN`, `ADMIN`), explicit role change blocking |
| **Audit Logging** | Production-Hardened | Immutable security events, automatic redaction of sensitive credentials and prompts |
| **Database Layer** | Production-Hardened | Prisma PostgreSQL schema, migrations applied, Token Minimization implemented |
| **AI Conversation Engine** | Deferred (Phase 2.2/3) | Interfaces defined; live model attachments scheduled |
| **Voice Pipelines** | Deferred (Phase 3) | Realtime WebSockets / WebRTC scheduled |

---

## Packaging & Download

To generate a clean ZIP archive of this complete Phase 2 project excluding `node_modules`, build artifacts, and secrets:

```bash
npm run package
```

The output file `niva-phase-2.zip` will be generated in the root directory. You can also download it directly from the live preview via the **"Download Phase 2 ZIP"** button or the `GET /api/download-zip` endpoint.
